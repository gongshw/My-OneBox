//eat_what.js
function rm_food (argument) {
	var mune=[];
	return '饿了吧~';
}
